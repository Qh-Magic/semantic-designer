---
name: data-catalog-semantic-layer
description: Generate governed semantic layer drafts from data catalog metadata, glossary terms, lineage, query history, BI usage, and data quality signals. Use when Codex needs to convert a data catalog export into entities, dimensions, measures, metrics, joins, synonyms, governance policies, validation tests, or demo-ready semantic layer YAML for BI tools, Text-to-SQL systems, or AI agents.
---

# Data Catalog Semantic Layer

## Overview

Use this skill to turn catalog metadata into a governed semantic layer draft. Default to a practical `draft` output with explicit assumptions; never claim production certification without owner evidence.

Ask a question only when the target platform or input location is unknown and cannot be inferred. If metadata is thin, proceed and mark low-confidence parts as `needs_review`.

## Workflow

1. Inventory the input catalog.
   - Identify available metadata: tables, columns, descriptions, glossary terms, lineage, owners, PII tags, quality scores, query history, BI usage, and access policies.
   - If only raw schemas are available, label the output as `draft` and lower confidence.

2. Build a semantic map.
   - Classify datasets as fact, dimension, bridge, event, snapshot, or reference.
   - Infer entities from stable identifiers and dimension tables.
   - Infer relationships from foreign keys, naming patterns, lineage, and repeated query joins.
   - Prefer fact-to-dimension or child-fact-to-parent joins; flag fact-to-fact joins unless lineage or query history supports them.
   - Infer candidate measures only from numeric columns with additive or countable meaning.
   - Infer metrics as governed formulas over measures, not as renamed raw columns.

3. Apply governance before writing the final layer.
   - Add owners, certification status, PII tags, access controls, freshness expectations, and data quality notes.
   - Mark ambiguous joins, metrics, and filters as `needs_review`.
   - Block raw PII from Agent-facing outputs unless the user explicitly requests a restricted internal model.

4. Produce a semantic layer artifact.
   - Default to tool-neutral YAML unless the user asks for dbt Semantic Layer, Cube, Looker, Power BI, Snowflake semantic views, Databricks metric views, or another format.
   - Include only useful sections: source assumptions, governance, entities, datasets, relationships, dimensions, measures, metrics, synonyms, validation, and review items.
   - Add assumptions and unresolved review items.
   - When a local semantic designer is the consumer, preserve the tool-neutral
     contract as the source and generate adapters; do not rewrite it directly
     into a vendor format as the only copy.

5. Validate the draft.
   - Check metric grains, join direction/cardinality, additive behavior, duplicate counting risk, PII false positives, and conflicting glossary definitions.
   - Create golden questions for BI or AI Agent testing.

## Output Contract

Every delivered semantic layer must include:

- `status`: `draft`, `reviewed`, or `certified`
- `source_catalog.limitations`
- `governance.agent_policy`
- `entities`, `datasets`, `relationships`, `measures`, and `metrics`
- confidence or review status for inferred metrics and joins
- at least 5 golden questions for demo or Agent-facing work
- a short list of human review items

## Fast Scaffold Script

When the user provides a catalog export in JSON or CSV, use:

```bash
python3 /path/to/data-catalog-semantic-layer/scripts/catalog_to_semantic_layer.py catalog.json --out semantic-layer.yaml
python3 /path/to/data-catalog-semantic-layer/scripts/catalog_to_semantic_layer.py catalog.csv --out semantic-layer.yaml
```

Supported CSV columns include: `table_name`, `column_name`, `data_type`, `column_description`, `business_term`, `pii_tag`, `owner`, `source_system`, `quality_score`, and `tags`.

The script creates a scaffold only. Improve the YAML before delivery; do not forward raw script output as final work.

Always do a curation pass after script generation: correct relationship direction, remove false PII classifications for product/brand/business names, downgrade unsupported business rules, and add review items for missing lineage, query history, data quality scores, freshness checks, and owner approval.

## Interoperability targets

The canonical output of this skill is the tool-neutral `semantic_layer` document.
For the local Semantic Designer, pass that document to
`load_catalog_semantic_layer`. The designer can then emit:

- Apache Ossie `0.3.0.dev0`: one semantic-model document containing datasets,
  fields, relationships, metrics, AI context, and non-portable extensions.
- AtScale SML: a repository of object files for datasets, metrics, and models.
  Complex formulas and catalog governance are preserved as explicit extensions
  and still require AtScale SML validation and owner review.

Ossie is the portable interchange boundary; AtScale SML is the deployable
AtScale-oriented object boundary. Neither generated format replaces the
catalog-originated canonical document. Preserve the original catalog metadata,
version, review status, and golden questions for round-trip auditing.

## References

- Read `references/inference-rules.md` only when metadata is imperfect or inference choices are non-obvious.
- Read `references/output-template.md` only when formatting a full YAML artifact or converting to a target semantic layer style.

## Quality Bar

Before final delivery:

- State whether the semantic layer is `draft`, `reviewed`, or `certified`.
- Include source catalog assumptions and any missing metadata.
- Keep business metrics separate from physical measures.
- Prefer aggregate-safe metrics and call out non-additive metrics.
- Include at least 5 golden questions for Agent or BI validation when the artifact is demo-facing.
- Never invent real operating numbers, customer records, or private policies.

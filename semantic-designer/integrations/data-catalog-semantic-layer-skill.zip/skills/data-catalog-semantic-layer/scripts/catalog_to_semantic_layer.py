#!/usr/bin/env python3
"""Create a draft semantic layer scaffold from a simple catalog JSON or CSV export.

This script intentionally uses only the Python standard library. It is a starter
generator, not a replacement for business-owner review.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


MEASURE_SUFFIXES = (
    "_amount",
    "_count",
    "_qty",
    "_quantity",
    "_revenue",
    "_cost",
    "_fee",
    "_spend",
    "_duration",
    "_score",
)

DIRECT_PII_PATTERNS = re.compile(r"(email|phone|address|birth|national|mobile)", re.I)
PERSON_NAME_PATTERNS = re.compile(r"(customer|member|user|person|contact|recipient|consignee).*name|name.*(customer|member|user|person|contact|recipient|consignee)", re.I)
NON_PII_NAME_PATTERNS = re.compile(r"(product|brand|campaign|category|seller|supplier|merchant|store).*name|name.*(product|brand|campaign|category|seller|supplier|merchant|store)", re.I)
ID_PATTERN = re.compile(r"(^id$|_id$)", re.I)


def load_catalog(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "tables" in data:
            return normalize_json_tables(data["tables"])
        if isinstance(data, list):
            return normalize_json_tables(data)
        raise SystemExit("JSON must be a list of tables or an object with a 'tables' key.")
    if path.suffix.lower() == ".csv":
        return normalize_csv_rows(path)
    raise SystemExit("Supported inputs: .json or .csv")


def normalize_json_tables(tables: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized = []
    for table in tables:
        columns = table.get("columns", [])
        normalized.append(
            {
                "name": table.get("name") or table.get("table_name"),
                "description": table.get("description", ""),
                "owner": table.get("owner", "needs_owner"),
                "source_system": table.get("source_system", "unknown"),
                "columns": [
                    {
                        "name": col.get("name") or col.get("column_name"),
                        "data_type": col.get("data_type") or col.get("type", "unknown"),
                        "description": col.get("description") or col.get("column_description", ""),
                        "business_term": col.get("business_term", ""),
                        "pii_tag": col.get("pii_tag", ""),
                        "tags": split_tags(col.get("tags", [])),
                    }
                    for col in columns
                    if col.get("name") or col.get("column_name")
                ],
            }
        )
    return [table for table in normalized if table["name"]]


def normalize_csv_rows(path: Path) -> list[dict[str, Any]]:
    tables: dict[str, dict[str, Any]] = {}
    with path.open(newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            table_name = row.get("table_name") or row.get("table") or row.get("dataset")
            column_name = row.get("column_name") or row.get("column")
            if not table_name or not column_name:
                continue
            table = tables.setdefault(
                table_name,
                {
                    "name": table_name,
                    "description": row.get("table_description", ""),
                    "owner": row.get("owner", "needs_owner"),
                    "source_system": row.get("source_system", "unknown"),
                    "columns": [],
                },
            )
            table["columns"].append(
                {
                    "name": column_name,
                    "data_type": row.get("data_type", "unknown"),
                    "description": row.get("column_description", ""),
                    "business_term": row.get("business_term", ""),
                    "pii_tag": row.get("pii_tag", ""),
                    "tags": split_tags(row.get("tags", "")),
                }
            )
    return list(tables.values())


def split_tags(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [part.strip() for part in str(value).split(",") if part.strip()]


def classify_table(name: str) -> str:
    n = name.lower()
    if n.startswith("fact_") or any(term in n for term in ["order", "transaction", "event", "click", "shipment"]):
        return "fact"
    if n.startswith("dim_") or any(term in n for term in ["customer", "member", "product", "supplier", "campaign"]):
        return "dimension"
    if "bridge" in n or "xref" in n or "mapping" in n:
        return "bridge"
    if "snapshot" in n or "daily" in n:
        return "snapshot"
    return "reference"


def is_numeric(data_type: str) -> bool:
    return bool(re.search(r"(int|number|numeric|decimal|float|double|amount)", data_type, re.I))


def pii_classification(column: dict[str, Any]) -> str:
    explicit = column.get("pii_tag")
    if explicit:
        return explicit
    name = column["name"]
    tags = " ".join(column.get("tags", []))
    business_term = column.get("business_term", "")
    combined = f"{name} {business_term} {tags}"
    if NON_PII_NAME_PATTERNS.search(combined):
        return "none"
    if DIRECT_PII_PATTERNS.search(combined) or PERSON_NAME_PATTERNS.search(combined):
        return "direct_identifier"
    if ID_PATTERN.search(name) and any(term in name.lower() for term in ["customer", "member", "user"]):
        return "pseudonymous_identifier"
    return "none"


def primary_key_for(table: dict[str, Any]) -> str | None:
    table_name = table["name"].lower()
    table_type = classify_table(table["name"])
    id_cols = [col["name"] for col in table["columns"] if col["name"].lower().endswith("_id")]
    if not id_cols:
        return None

    base = table_name
    for prefix in ("fact_", "dim_"):
        base = base.removeprefix(prefix)
    singular = base[:-1] if base.endswith("s") else base
    preferred = [f"{singular}_id", f"{base}_id"]
    for candidate in preferred:
        for col in id_cols:
            if col.lower() == candidate:
                return col

    if table_type == "dimension":
        return id_cols[0]
    return id_cols[0] if len(id_cols) == 1 else None


def infer_measure(column: dict[str, Any], table_name: str) -> dict[str, Any] | None:
    name = column["name"]
    lower = name.lower()
    if not is_numeric(column.get("data_type", "")):
        return None
    if lower.endswith(MEASURE_SUFFIXES):
        agg = "sum"
        if lower.endswith(("_score", "_duration")):
            agg = "avg"
        return {
            "name": f"{table_name}_{name}",
            "expr": f"sum({table_name}.{name})" if agg == "sum" else f"avg({table_name}.{name})",
            "type": agg,
            "source_column": f"{table_name}.{name}",
            "certification": "draft",
            "confidence": "medium",
        }
    return None


def infer_relationships(tables: list[dict[str, Any]]) -> list[dict[str, Any]]:
    primary_keys = defaultdict(list)
    table_by_name = {table["name"]: table for table in tables}
    for table in tables:
        pk = primary_key_for(table)
        if pk:
            primary_keys[pk.lower()].append(table["name"])

    relationships = []
    for table in tables:
        if classify_table(table["name"]) not in {"fact", "snapshot", "bridge"}:
            continue
        own_pk = primary_key_for(table)
        for col in table["columns"]:
            key = col["name"].lower()
            if not key.endswith("_id") or col["name"] == own_pk:
                continue
            candidates = [t for t in primary_keys.get(key, []) if t != table["name"]]
            candidates.sort(key=lambda t: 0 if classify_table(t) == "dimension" else 1)
            if not candidates:
                continue
            target = candidates[0]
            relationships.append(
                {
                    "name": f"{table['name']}_to_{target}",
                    "from": f"{table['name']}.{col['name']}",
                    "to": f"{target}.{primary_key_for(table_by_name[target]) or col['name']}",
                    "type": "many_to_one",
                    "join_type": "left",
                    "review_status": "needs_review",
                    "confidence": "medium" if classify_table(target) == "dimension" else "low",
                }
            )
    return relationships


def build_semantic_layer(tables: list[dict[str, Any]]) -> dict[str, Any]:
    entities = []
    datasets = []
    dimensions = []
    measures = []
    pii_policy = {}

    for table in tables:
        table_type = classify_table(table["name"])
        datasets.append(
            {
                "name": table["name"],
                "source": f"{table.get('source_system', 'unknown')}.{table['name']}",
                "classification": table_type,
                "owner": table.get("owner", "needs_owner"),
                "certification": "draft",
            }
        )

        id_cols = [c for c in table["columns"] if c["name"].lower().endswith("_id")]
        if table_type == "dimension" and id_cols:
            entities.append(
                {
                    "name": table["name"].removeprefix("dim_"),
                    "primary_key": id_cols[0]["name"],
                    "dataset": table["name"],
                    "owner": table.get("owner", "needs_owner"),
                    "certification": "draft",
                    "confidence": "medium",
                }
            )

        for col in table["columns"]:
            pii = pii_classification(col)
            if pii != "none":
                pii_policy[f"{table['name']}.{col['name']}"] = {
                    "classification": pii,
                    "access": "restricted" if pii == "direct_identifier" else "role_based",
                    "masking": "full_mask" if pii == "direct_identifier" else "hash_for_general_analytics",
                }

            measure = infer_measure(col, table["name"])
            if measure:
                measures.append(measure)
            elif not ID_PATTERN.search(col["name"]):
                dimensions.append(
                    {
                        "name": f"{table['name']}_{col['name']}",
                        "expr": f"{table['name']}.{col['name']}",
                        "source_column": f"{table['name']}.{col['name']}",
                        "type": "categorical",
                        "pii": pii,
                        "certification": "draft",
                    }
                )

    return {
        "semantic_layer": {
            "name": "catalog_generated_semantic_layer",
            "version": "0.1.0",
            "status": "draft",
            "source_catalog": {
                "limitations": [
                    "Generated from catalog metadata only.",
                    "Business owner review is required before production use.",
                ]
            },
            "governance": {
                "certification_levels": ["draft", "reviewed", "certified", "deprecated"],
                "pii_policy": pii_policy,
                "agent_policy": {
                    "block_raw_pii_in_responses": True,
                    "require_metric_certification_for_external_reporting": True,
                    "require_source_citation": True,
                },
            },
            "entities": entities,
            "datasets": datasets,
            "relationships": infer_relationships(tables),
            "dimensions": dimensions,
            "measures": measures,
            "metrics": infer_basic_metrics(measures),
            "validation": {
                "golden_questions": [
                    "What are the top business metrics by month?",
                    "Which dimensions explain changes in the primary metric?",
                    "Are there any restricted fields in the requested answer?",
                    "Which joins need owner review before certification?",
                    "Which draft metrics are used in external reporting?",
                ],
                "review_items": [
                    "Confirm metric formulas and filters with business owners.",
                    "Verify join cardinality and grain.",
                    "Confirm PII masking and role-based access policies.",
                ],
            },
        }
    }


def infer_basic_metrics(measures: list[dict[str, Any]]) -> list[dict[str, Any]]:
    metrics = []
    for measure in measures:
        name = measure["name"]
        if any(term in name for term in ["revenue", "amount", "cost", "spend"]):
            metrics.append(
                {
                    "name": name.replace("fact_", "").replace("_amount", ""),
                    "formula": name,
                    "owner": "needs_owner",
                    "certification": "draft",
                    "confidence": measure["confidence"],
                    "business_definition": f"Draft metric based on {measure['source_column']}.",
                }
            )
    return metrics


def yaml_scalar(value: Any) -> str:
    if value is True:
        return "true"
    if value is False:
        return "false"
    if value is None:
        return "null"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if not text or any(ch in text for ch in ":#[]{}&,*?|<>=!%@`"):
        return json.dumps(text, ensure_ascii=False)
    return text


def to_yaml(value: Any, indent: int = 0) -> str:
    pad = " " * indent
    if isinstance(value, dict):
        lines = []
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                lines.append(f"{pad}{key}:")
                lines.append(to_yaml(item, indent + 2))
            else:
                lines.append(f"{pad}{key}: {yaml_scalar(item)}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return f"{pad}[]"
        lines = []
        for item in value:
            if isinstance(item, (dict, list)):
                rendered = to_yaml(item, indent + 2)
                first, *rest = rendered.splitlines()
                lines.append(f"{pad}- {first.strip()}")
                lines.extend(rest)
            else:
                lines.append(f"{pad}- {yaml_scalar(item)}")
        return "\n".join(lines)
    return f"{pad}{yaml_scalar(value)}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("catalog", type=Path, help="Catalog export in JSON or CSV format.")
    parser.add_argument("--out", type=Path, default=Path("semantic-layer.yaml"), help="Output YAML path.")
    args = parser.parse_args()

    tables = load_catalog(args.catalog)
    semantic_layer = build_semantic_layer(tables)
    args.out.write_text(to_yaml(semantic_layer) + "\n", encoding="utf-8")
    print(f"Wrote draft semantic layer to {args.out}")


if __name__ == "__main__":
    main()

# Output Template

Default to tool-neutral YAML unless the user requests a target tool.

## Required Sections

```yaml
semantic_layer:
  name: example_semantic_layer
  version: 0.1.0
  status: draft
  source_catalog:
    exported_at: unknown
    systems: []
    limitations: []
  governance:
    owners: []
    certification_levels: [draft, reviewed, certified, deprecated]
    pii_policy: {}
    agent_policy:
      block_raw_pii_in_responses: true
      require_metric_certification_for_external_reporting: true
      require_source_citation: true
  entities: []
  datasets: []
  relationships: []
  dimensions: []
  measures: []
  metrics: []
  semantic_synonyms: {}
  validation:
    golden_questions: []
    tests: []
    review_items: []
```

## Recommended Metric Shape

```yaml
- name: average_order_value
  display_name: Average Order Value
  formula: net_sales_amount / nullif(order_count, 0)
  format: currency
  owner: commerce_data_owner
  certification: reviewed
  confidence: medium
  business_definition: Net sales divided by distinct orders.
  allowed_dimensions:
    - order_date
    - sales_channel
    - product_category
  caveats:
    - Excludes cancelled orders if order status is available.
```

## Recommended Relationship Shape

```yaml
- name: orders_to_customers
  from: fact_orders.customer_id
  to: dim_customers.customer_id
  type: many_to_one
  join_type: left
  confidence: medium
  review_status: needs_review
  caveats:
    - Verify customer_id uniqueness in dim_customers.
```

## Review Checklist

- Are all metrics tied to measures or formulas, not vague descriptions?
- Are non-additive values modeled as ratios or snapshots instead of sums?
- Are joins cardinality-safe?
- Are PII and restricted financial fields masked or role-gated?
- Are owner and certification fields populated?
- Are demo assumptions explicit?
- Are golden questions aligned to business use cases?

# Inference Rules

Use these rules when catalog metadata is incomplete or inconsistent.

## Dataset Classification

| Signal | Likely classification | Notes |
|---|---|---|
| table name starts with `fact_`, contains orders, transactions, events, clicks, shipments | fact or event | Usually contains measures and foreign keys |
| table name starts with `dim_`, contains customer, product, account, merchant, supplier | dimension | Usually contains descriptive attributes |
| contains two or more foreign keys and few attributes | bridge | Use for many-to-many relationships |
| contains date grain plus status balances | snapshot | Be careful with additive metrics |
| contains code, type, status, category | reference | Useful for dimensions and filters |

## Entity Inference

Create an entity when there is a stable identifier such as `customer_id`, `product_id`, `order_id`, `campaign_id`, `account_id`, or a glossary-backed business object.

Do not create entities from volatile identifiers such as session IDs unless the use case is behavioral analytics.

## Dimension Inference

Good dimensions:

- categorical status, type, segment, region, channel, category, brand
- dates and timestamps used for filtering or grouping
- low-cardinality flags
- governed geography values

Avoid raw text blobs, raw PII, long descriptions, JSON payloads, and unconstrained IDs as general dimensions.

## Measure Inference

Candidate measures usually include numeric columns ending in:

- `_amount`
- `_count`
- `_qty`
- `_quantity`
- `_revenue`
- `_cost`
- `_fee`
- `_spend`
- `_duration`
- `_score`

Default aggregation:

- amount, revenue, cost, fee, spend, quantity: `sum`
- IDs: `count_distinct` only when counting business objects
- rate, percent, ratio, score: not additive; create as metrics from numerator and denominator when possible
- balance, inventory, snapshot values: semi-additive; require date-grain guidance

## Metric Inference

Create metrics as governed formulas with owner and certification status. Examples:

- average_order_value = net_sales_amount / order_count
- conversion_rate = converted_sessions / sessions
- return_rate = returned_order_count / order_count
- on_time_delivery_rate = on_time_shipments / shipments
- roas = attributed_revenue / ad_spend

For every metric, include:

- business definition
- formula
- grain
- dimensions allowed for breakdown
- owner
- certification status
- known caveats

## Relationship Inference

Use explicit catalog foreign keys first. If absent, use naming patterns:

- `fact_orders.customer_id -> dim_customers.customer_id`
- `fact_order_items.product_id -> dim_products.product_id`
- bridge tables for many-to-many relationships

Prefer relationship targets in this order:

1. dimension tables with the matching key
2. parent fact tables whose primary key matches a child fact foreign key
3. bridge tables only when many-to-many is clear

Skip joins from a table's own primary key to another table with the same key unless lineage or query history proves the direction. For example, avoid `fact_orders.order_id -> fact_order_items.order_id`; prefer `fact_order_items.order_id -> fact_orders.order_id`.

Flag `needs_review` when:

- a join key is not unique on the dimension side
- two possible dimensions share the same key
- query history shows conflicting join paths
- a join crosses domains with different access policies

## Governance Inference

PII signals:

- direct identifiers: person/customer/member/user name, email, phone, address, national_id
- pseudonymous identifiers: customer_id, member_id, user_id
- sensitive traits: birthdate, gender, income, precise location, health-related attributes

Do not classify product names, brand names, campaign names, category names, seller names, or supplier display names as PII unless catalog tags explicitly mark them sensitive.

Default policies:

- Direct identifiers: restricted, masked by default
- Pseudonymous identifiers: role-based access, hashed for broad analytics
- Financial costs and margins: restricted unless owner certifies public use
- Draft metrics: allowed for exploration, blocked for external reporting

## Confidence

Use confidence labels:

- `high`: backed by glossary, owner, lineage, and query usage
- `medium`: backed by schema and repeated naming/query patterns
- `low`: inferred from names only

Never present low-confidence metrics as certified.

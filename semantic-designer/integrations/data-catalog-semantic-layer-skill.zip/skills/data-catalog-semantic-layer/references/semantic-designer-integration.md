# Semantic Designer Integration

Use the catalog-generated document as the canonical input to the local Semantic Designer.

```python
from server import load_catalog_semantic_layer, ossie_document, write_sml_repository

model = load_catalog_semantic_layer("semantic-layer.yaml")
ossie = ossie_document(model)
write_sml_repository(model, "generated-sml")
```

## Mapping

| Catalog skill | Designer | Apache Ossie | AtScale SML |
|---|---|---|---|
| `datasets` | `models` | `datasets` | `dataset` objects |
| `relationships` | normalized `from` / `to` | `from_columns` / `to_columns` | model relationships |
| `measures`, `metrics` | `metrics` | dataset/model metrics | `metric` objects |
| `governance`, `source_catalog` | model extensions | `nonportable_extensions` | semantic-designer extension |

The adapter can synthesize a narrow placeholder model when a relationship names an
entity that has no physical dataset in the catalog export. Such models are marked
`synthetic_from_entity` and must be resolved by a data owner before publication.

Ossie expressions use `OSSIE_SQL_2026`-compatible SQL where possible. SML object
files preserve complex formulas in an explicit `expression` extension; validate them
with the AtScale SML tooling before deployment.

# Data Catalog Semantic Layer Skill

這個 skill 叫做 `data-catalog-semantic-layer`，用途是當你有 Data Catalog metadata，例如 tables、columns、business glossary、lineage、owners、PII tags、query history、BI usage 等資料時，協助 Codex 把它轉成一份可治理的 Semantic Layer 草稿。

它不是單純把 schema 轉 YAML，而是會把資料治理也放進去：哪些是 entity、哪些是 fact/dimension、哪些欄位可當 measure、哪些 metric 需要 owner review、哪些欄位含 PII、哪些 join 有風險、哪些 metric 可以給 AI Agent 或 BI 使用。

## Skill 內容

主要檔案：

- `SKILL.md`

`SKILL.md` 定義完整工作流程：

1. 盤點 catalog 輸入：檢查 table、column、description、glossary、lineage、owner、PII tag、quality score、query history 等。
2. 建立 semantic map：判斷哪些表是 fact、dimension、bridge、snapshot、reference，並推論 entities、relationships、dimensions、measures、metrics。
3. 套用治理規則：加上 owner、certification status、PII masking、access control、freshness、review items。
4. 產出 semantic layer：預設產生工具中立 YAML，也可以要求轉成 dbt Semantic Layer、Cube、Looker、Power BI、Snowflake semantic views、Databricks metric views 等格式。
5. 驗證草稿：檢查 metric grain、join cardinality、重複計算風險、PII 曝露、glossary 衝突，並產生 golden questions 給 BI 或 AI Agent 測試。

## 參考文件

### `references/inference-rules.md`

這份是推論規則，包含：

- 如何判斷 fact / dimension / bridge / snapshot
- 如何從 `customer_id`、`product_id` 等欄位推 entity
- 哪些欄位適合當 dimension
- 哪些 numeric 欄位適合當 measure
- rate、ratio、score 這類非加總欄位怎麼處理
- 如何推論 joins
- 如何辨識 PII 與治理政策
- 如何標示 confidence：high / medium / low

### `references/output-template.md`

這份定義 semantic layer 輸出格式，包含：

- `entities`
- `datasets`
- `relationships`
- `dimensions`
- `measures`
- `metrics`
- `semantic_synonyms`
- `governance`
- `validation`
- `golden_questions`
- `review_items`

## 自動產生草稿的腳本

腳本位置：

- `scripts/catalog_to_semantic_layer.py`

這支腳本可以把簡單的 catalog export 轉成 semantic layer YAML 草稿。

支援 JSON / CSV。

CSV 建議欄位：

```csv
table_name,column_name,data_type,column_description,business_term,pii_tag,owner,source_system,tags
```

使用 CSV：

```bash
python3 scripts/catalog_to_semantic_layer.py catalog.csv --out semantic-layer.yaml
```

使用 JSON：

```bash
python3 scripts/catalog_to_semantic_layer.py catalog.json --out semantic-layer.yaml
```

輸出的 YAML 會是 `draft`，還需要人工審核 metric 定義、join 關係與 governance policy。

## 與 Semantic Designer、Apache Ossie、AtScale SML 整合

產物的 `semantic_layer` 是 canonical tool-neutral contract。若要交給本地
Semantic Designer，可使用：

```python
from server import load_catalog_semantic_layer, ossie_document, write_sml_repository

model = load_catalog_semantic_layer("semantic-layer.yaml")
ossie = ossie_document(model)                 # Apache Ossie 0.3.0.dev0 document
write_sml_repository(model, "generated-sml")  # AtScale SML-shaped object files
```

這條流程會保留 governance、source limitations、原始 catalog metadata 與
review context。Ossie 是跨工具交換格式；SML 是 AtScale 導向的 object
repository。complex metric expression、row security 與 vendor-specific
policy 不保證可在兩者間無損轉換，必須再跑對應 validator、AtScale SML CLI
與 golden queries。

## 你可以怎麼叫用它

可以直接對 Codex 說：

```text
使用 data-catalog-semantic-layer skill，把這份 catalog CSV 轉成 semantic layer
```

或：

```text
用 $data-catalog-semantic-layer，根據這些 table schema 和 glossary 幫我產生 semantic layer YAML
```

也可以指定目標格式：

```text
用 $data-catalog-semantic-layer，把這份 data catalog 轉成 dbt Semantic Layer 格式
```

```text
用 $data-catalog-semantic-layer，產生一份可給 AI Agent 做 Text-to-SQL 的 semantic layer，並加入 PII governance policy
```

## 最適合的輸入

效果最好的是提供這些資料：

- catalog export CSV / JSON
- table 與 column description
- business glossary
- table owner / domain owner
- PII / sensitive tags
- lineage
- 常用 SQL 或 dashboard 使用紀錄
- data quality score 或 freshness SLA

如果只有 schema，它也能產出草稿，但會把很多東西標成 `draft`、`needs_review` 或低 confidence。

## 建議使用流程

1. 從 data catalog 匯出 metadata。
2. 叫用 `$data-catalog-semantic-layer` 產生第一版 YAML。
3. 檢查 `review_items`。
4. 找 domain owner 確認 metrics 與 joins。
5. 把通過的 metric 從 `draft` 改成 `reviewed` 或 `certified`。
6. 用 golden questions 測 AI Agent / BI 查詢是否穩定。
7. 再轉成 dbt、Cube、Looker 或其他正式 semantic layer 格式。

## 目錄結構

```text
data-catalog-semantic-layer/
├── SKILL.md
├── README.md
├── agents/
│   └── openai.yaml
├── references/
│   ├── inference-rules.md
│   └── output-template.md
└── scripts/
    └── catalog_to_semantic_layer.py
```
